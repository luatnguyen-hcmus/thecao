<?php 
	Class Cash_card_model extends MY_Model{
		var $table = 'cash_card';
	}