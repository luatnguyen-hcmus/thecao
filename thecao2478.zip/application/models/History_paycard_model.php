<?php 
	Class History_paycard_model extends MY_Model{
		var $table = 'history_paycard';
	}