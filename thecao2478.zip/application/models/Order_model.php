<?php 
	Class Order_model extends MY_Model{
		var $table = "order";
	}