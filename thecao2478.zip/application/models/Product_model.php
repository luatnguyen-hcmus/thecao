<?php 
	Class Product_model extends MY_Model{
		var $table = 'product';
	}