<?php 
	Class Typecard_model extends MY_Model{
		var $table = 'type_card';
		
	}