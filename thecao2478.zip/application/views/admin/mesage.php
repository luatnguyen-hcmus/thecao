<?php if(isset($message) && $message):?>

<div class="nNote nInformation hideit">
	<p><strong>Thông báo: </strong><?php echo $message; ?></p>
</div>
<?php endif?>