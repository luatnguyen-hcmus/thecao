<div style="text-align: center;margin:0 auto;">
  <img src="<?php echo public_url('site/images/hinhbaotri.jpg')?>" width='50%' height="200px" />
</div>