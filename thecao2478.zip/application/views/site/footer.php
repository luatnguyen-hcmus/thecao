
    <div class="navbar-default">
        <div class="container">
            <div style="text-align: center">
                <ul class="nav navbar-nav">
                    <li><a href="<?php echo base_url('/dieukhoan')?>">Chính sách &amp; điều khoản sử dụng</a></li>
                    <li><a href="#">Bảo mật thông tin khách hàng</a></li>
                    <li><a href="#">Chính sách đổi trả</a></li>
                </ul>
            </div>
        </div>
    </div>
