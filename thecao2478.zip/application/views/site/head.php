<meta http-equiv="content-type" content="text/html">
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta name="title" content="Đổi thẻ cào thành tiền mặt - thanh toán cược viễn thông giá rẻ">
<meta name="description" content="Dịch vụ mua bán thẻ cào uy tín với chiếc khấu cực thấp">
<meta name="keywords" content="banthe, doi the thanh tien, web nap tien, vi dien tu, nap tien, hau nguyen">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta property="og:image:width" content="600">
<meta property="og:image:height" content="315">
<meta property="og:url" content="<?php echo base_url()?>">
<meta property="og:type" content="website">
<meta property="og:title" content="Đổi thẻ cào thành tiền mặt - thanh toán cược viễn thông giá rẻ">
<meta property="og:description" content="Dịch vụ mua bán thẻ cào uy tín với chiếc khấu cực thấp">
<link rel="shortcut icon" href="<?php echo public_url()?>/admin/images/icon.jpg" type="image/x-icon"/>
<meta property="og:site_name" content="<?php echo base_url()?>">
<title>Đổi thẻ cào thành tiền mặt - thanh toán cược viễn thông giá rẻ</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="<?php echo public_url('site/css/bootstrap.min.css')?>">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<link href="https://vitalets.github.io/bootstrap-datepicker/bootstrap-datepicker/css/datepicker.css" rel="stylesheet">
<script src="https://vitalets.github.io/bootstrap-datepicker/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>    

<script src="<?php echo public_url('site/js/bootstrap.min.js')?>"></script>
<script src="<?php echo public_url('site/js/jquery.form.js')?>"></script>
<script src="<?php echo public_url('site/js/jshashtable-3.0.js')?>"></script>
<script src="<?php echo public_url('site/js/jquery.numberformatter-1.2.4.min.js')?>"></script>
<link rel="stylesheet" href="<?php echo public_url('site/css/jquery-ui.css')?>">

<link rel="stylesheet" href="<?php echo public_url('site/css/font-awesome.min.css')?>">
<link rel="stylesheet" href="<?php echo public_url('site/css/style.css')?>">



<script type='text/javascript'>
//<![CDATA[
// JavaScript Document
var message="NoRightClicking"; function defeatIE() {if (document.all) {(message);return false;}} function defeatNS(e) {if (document.layers||(document.getElementById&&!document.all)) { if (e.which==2||e.which==3) {(message);return false;}}} if (document.layers) {document.captureEvents(Event.MOUSEDOWN);document.onmousedown=defeatNS;} else{document.onmouseup=defeatNS;document.oncontextmenu=defeatIE;} document.oncontextmenu=new Function("return false")
//]]>
</script>
<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js'/>
<script type='text/javascript'>
checkCtrl=false $(&#39;*&#39;).keydown(function(e){
if(e.keyCode==&#39;17&#39;){ checkCtrl=false  } }).keyup(function(ev){
if(ev.keyCode==&#39;17&#39;){ checkCtrl=false } }).keydown(function(event){
if(checkCtrl){
if(event.keyCode==&#39;85&#39;){ return false; } } })
</script>

 
