<div class="container">
<div class="row">
<div class="col-md-12">
<div class="page-header">
<h3>Điều khoản</h3>
</div>
<p style="text-align:center"><strong>THỎA THUẬN SỬ DỤNG DỊCH VỤ</strong></p>
<p style="text-align:center"><strong>CAM KẾT BẮT BUỘC CỦA NGƯỜI SỬ DỤNG DỊCH VỤ TRÊN WEBSITE</strong></p>
<p>Nội dung</p>

</div>
</div>
</div>